#####################################
# Python Temelleri - Ödev Scripti
#####################################

# Soru 1:
a=7
b=3.14
c=5+2j
print(type(a),type(b),type(c))
print(a+b)
print(c*b)

# Soru 2:
isim="mehmet"
print(isim[0],isim[-1])
print(isim.upper())

# Soru 3:
sentence = "Veri bilimi yapay zeka ile birleştiğinde güçlü sonuçlar doğurabilir."
print("veri" in sentence.lower())
print(sentence.split())

# Soru 4:
liste=[True,5,"hello"]
print(len(liste))
print(liste[0],liste[-1])
liste.append("ekleme")
del liste[1]
print(liste)

# Soru 5:
def ortalama(s1,s2):
  return (s1+s2)/2

print(ortalama(10,20))

# Soru 6:
def yas_kontrol(y):
  if y<18:
    print("çok gençsin!")
  elif y<=40:
    print("harika bi yaştasın!")
  else:
    print("deneyim önemli!")

yas_kontrol(35)
yas_kontrol(15)
yas_kontrol(45)

# Soru 7:
sayilar=[1,2,3,4,5]
for s in sayilar:
  print(s*2)

# Soru 8:
x=1
while x<=20:
  if x%2==0:
    print(x)
  x+=1

# Soru 9:
def maas(saatlik,h_saat):
  if h_saat<=40:
    return saatlik*h_saat
  else:
    fazla=h_saat-40
    return saatlik*40+fazla*saatlik*1.5

print(maas(100,45))
