###############################
# Numpy & Pandas - Ödev Soruları
###############################

import numpy as np
import pandas as pd
import seaborn as sns

###############################
# Soru 1:
# 1D ve 2D array'ler oluşturun.
# Bu array’lerin boyut, eleman sayısı ve şekil bilgilerini yazdırın.
d1=np.array([1,2,3,4])
d2=np.array([[7,8],[9,10]])
print(d1.shape,d1.size,d1.ndim)
print(d2.shape,d2.size,d2.ndim)

###############################
# Soru 2:
# 5 elemanlı rastgele sayılardan oluşan bir array oluşturun.
# Elemanların ortalamasını, standart sapmasını ve medyanını bulun.
rs=np.random.rand(5)
print(rs.mean(),np.std(rs),np.median(rs))

###############################
# Soru 3:
# 0 ile 1 arasında 10 eşit aralıklı sayı üretin.
# Bu sayılardan 0.5'ten büyük olanları filtreleyip yazdırın.
aralik=np.linspace(0,1,10)
filtre=aralik[aralik>0.5]
print(filtre)

###############################
# Soru 4:
# Pandas Series kullanarak öğrencilerin yaşlarını tutan bir seri oluşturun.
# Yaş ortalamasını ve en küçük yaşı bulun.
yas=pd.Series([21,18,22,17,20])
print(yas.mean(),yas.min())

###############################
# Soru 5:
# seaborn içerisinden "diamonds" veri setini alın.
# Sadece "carat" ve "price" sütunlarını içeren ilk 5 satırı yazdırın.
df=sns.load_dataset("diamonds")
print(df[["carat","price"]].head())

###############################
# Soru 6:
# Fiyatı 15.000’den fazla olan kaç elmas var?
print(len(df[df.price>15000]))

###############################
# Soru 7:
# “cut” sütunundaki her bir kesim tipi için ortalama fiyatı(price) hesaplayın.
print(df.groupby("cut")["price"].mean())

###############################
# Soru 8:
# pivot_table kullanarak her “cut” tipi için hem ortalama “carat” hem de “price” değerlerini gösterin.
print(df.pivot_table(values=["carat","price"],index="cut",aggfunc="mean"))

###############################
# Soru 9:
# “color” sütununda kaç farklı renk olduğunu bulun. Her bir rengin kaç kez geçtiğini de yazdırın.
print(df["color"].nunique())
print(df["color"].value_counts())

###############################
# Soru 10:
# “cut” ve “clarity” kombinasyonlarına göre ortalama fiyatları hesaplayın.
print(df.pivot_table(values="price",index=["cut","clarity"],aggfunc="mean"))
